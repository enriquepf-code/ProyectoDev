
export default function NotFoundView() {
  return (
    <p className="font-bold text-2xl text-center text-white">Usuario No Encontrado</p>
  )
}
